import java.util.Scanner;

public class chapter1_4 {
		public static void main(String [] args)	{
			Scanner scanner = new Scanner(System.in);
			
			System.out.print("여행지를 입력하세요:");
			String destination = scanner.nextLine();
			
			System.out.print("사람수를 입력하세요:");
			int a = scanner.nextInt();
			
			System.out.print("숙박일를 입력하세요:");
			int b = scanner.nextInt();
			
			System.out.print("1인당 항공료를 입력하세요:");
			int c = scanner.nextInt();
			
			System.out.print("방 1개의 숙박료를 입력하세요:");
			int d = scanner.nextInt();
			
			int e = (a + 1) / 2;
			
			int f = (a * c) + (e * b * d);
			
			System.out.print(f);
		}

}
