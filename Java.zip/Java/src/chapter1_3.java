import java.util.Scanner;

public class chapter1_3 {
		public static void main(String [] args)	{
			Scanner scanner = new Scanner(System.in);
			
			System.out.print("생년월일을 입력하세요(띄어쓰기없이8숫자):");
			int a = scanner.nextInt();
			int b = a % 100;
			int c = (a / 100) % 100;
			int d = (a / 100) / 100;
			
			System.out.print(d + "년");
			System.out.print(c + "월");
			System.out.print(b + "일");
			
			scanner.close();
		}
}
